#include <stdio.h>

int rt(int argc, char** argv) {
	int i;
	for (i=1; i<= 100;i++){
		printf("%d\n",i);
	}
	return 0;
	
}
