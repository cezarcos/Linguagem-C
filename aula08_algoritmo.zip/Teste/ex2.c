#include <stdio.h>

int contagem(int argc, char** argv) {
	int i = 1;
	while (i<=50){
		if (i%2==0){
			printf("%d\n",i);
		}
		i++;
	}
}

