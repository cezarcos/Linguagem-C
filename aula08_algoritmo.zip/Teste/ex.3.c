#include <stdio.h>

int regressiva(int argc, char** argv) {
	int i= 10;
	do {
		printf("%d\n", i);
		i--;
	} while (i >= 0);
	printf("Fim da contagem! \n");
	return 0;
}

